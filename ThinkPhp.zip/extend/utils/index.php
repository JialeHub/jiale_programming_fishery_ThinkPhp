<?php


namespace utils;


/**
 * Class 常用工具类
 *
 * @author   Jiale Luo
 * @version: 1.0.0
 * @datetime 2020-12-11
 * @package utils
 */
class index
{

  /**
   *  * 二维数组排序
   *  * @param array $arr 需要排序的二维数组
   *  * @param string $keys 所根据排序的key
   *  * @param string $type 排序类型，desc、asc
   *  * @return array $new_array 排好序的结果
   *  */

  public function array_sort($arr, $keys, $type = 'desc')
  {
    $key_value = $new_array = array();
    foreach ($arr as $k => $v) {
      $keysArray = explode('.', $keys);
      $eval_array=array_map(function($k){return "["."\"".$k."\""."]";},$keysArray);
      $key_value[$k] = eval(('return $v').implode($eval_array) .';');
//      $key_value[$k] = $v[$keys];
    }
    if ($type == 'asc') {
      asort($key_value);
    } else {
      arsort($key_value);
    }
    reset($key_value);
    foreach ($key_value as $k => $v) {
      $new_array[$k] = $arr[$k];
    }
    return $new_array;
  }


  /**
   * 数组层级缩进转换
   * @link https://blog.csdn.net/lyphper/article/details/70332425
   * @param $array
   * @param boolean $desc
   * @param string $sortKey
   * @param int $pid
   * @param int $level
   * @return array
   */
  public function array2level($array, $pid = 0, $level = 1, $desc = false, $sortKey = 'sort'): array
  {
    static $list = [];
//    if($sortKey) $array = $this->array_sort($array, $sortKey, $desc?'desc':'asc');
    foreach ($array as $v) {
      // null == 0 为真
      if ($v['pid'] == $pid) {
        $v['level'] = $level;
        $list[] = $v;
        $this->array2level($array, $v['id'], $level + 1, $desc, $sortKey);
      }
    }
    return $list;
  }

  /**
   * 形成树状格式
   * @param $tree
   * @param boolean $desc
   * @param string $sortKey
   * @param int $rootId
   * @param int $level
   * @return array
   */
  public function arr2tree($tree, $rootId = 0, $level = 1, $desc = false, $sortKey = 'sort')
  {
    $return = array();
    if($sortKey) $tree = $this->array_sort($tree, $sortKey, $desc?'desc':'asc');
    foreach ($tree as $leaf) {
      if ($leaf['pid'] == $rootId) {
        $leaf["level"] = $level;
        foreach ($tree as $subLeaf) {
          if ($subLeaf['pid'] == $leaf['id']) {
            $leaf['children'] = $this->arr2tree($tree, $leaf['id'], $level + 1, $desc, $sortKey);
            break;
          }
        }
        $return[] = $leaf;
      }
    }
    return $return;
  }

  /**
   * 文件夹路径规整化..和.
   * @param $dirPath
   * @return string
   */
  public function dirPathFormat($dirPath)
  {
    $path = str_replace(array('/', '\\'), DIRECTORY_SEPARATOR, $dirPath);
    //过滤掉多个/ 的 比如a/c//d
    $parts = array_filter(explode(DIRECTORY_SEPARATOR, $path), 'strlen');
    //首个路径不用管，可能是'', '..', '.', '其他'
    $first = array_shift($parts);
    $path = [];
    foreach ($parts as $part) {
      if ($part === '.') {
        //一个点代表当前路径不用处理
        continue;
      } elseif ($part === '..' && end($path) !== false && end($path) !== '..') {
        //这里有可能前面有几个双点 比如 ../../../a/b/c
        array_pop($path);
      } else {
        $path[] = $part;
      }
    }
    array_unshift($path, $first);
    return implode(DIRECTORY_SEPARATOR, $path);
  }

  /**
   * URL路径规整化
   * @param $path
   * @return string
   */
  public function urlPathFormat($path)
  {
    //转换dos路径为*nix风格
    $path = str_replace('\\', '/', $path);
    //替换$path中的 /xxx/../ 为 / ，直到替换后的结果与原串一样（即$path中没有/xxx/../形式的部分）
    $last = '';
    while ($path != $last) {
      $last = $path;
      $path = preg_replace('/\/[^\/]+\/\.\.\//', '/', $path);
    }
    //替换掉其中的 ./ 部分 及 //  部分
    $last = '';
    while ($path != $last) {
      $last = $path;
      $path = preg_replace('/([\.\/]\/)+/', '/', $path);
    }
    return $path;
  }


  /**
   * 度分秒转经纬度
   * @param $dmsData
   * @return string
   */
  public function Dms2D($dmsData)
  {
    if (is_array($dmsData) && count($dmsData) === 3) {
      $d = eval('return (' . $dmsData[0] . ");");
      $m = eval('return (' . $dmsData[1] . ");");
      $s = eval('return (' . $dmsData[2] . ");");
      return $d + $m / 60 + $s / 60 / 60;
    } else {
      return 0;
    }
  }

  /**
   * 下划线转驼峰
   * 思路:
   * step1.原字符串转小写,原字符串中的分隔符用空格替换,在字符串开头加上分隔符
   * step2.将字符串中每个单词的首字母转换为大写,再去空格,去字符串首部附加的分隔符.
   */
  public function camelize($uncamelized_words, $separator = '_')
  {
    $uncamelized_words = $separator . str_replace($separator, " ", strtolower($uncamelized_words));
    return ltrim(str_replace(" ", "", ucwords($uncamelized_words)), $separator);
  }

  /**
   * 驼峰命名转下划线命名
   * 思路:
   * 小写和大写紧挨一起的地方,加上分隔符,然后全部转小写
   */
  public function uncamelize($camelCaps, $separator = '_')
  {
    return strtolower(preg_replace('/([a-z])([A-Z])/', "$1" . $separator . "$2", $camelCaps));
  }

  //数组键驼峰命名转下划线命名
  public function uncamelizeArrKeys($camelCaps, $separator = '_')
  {
    $temp = [];
    $listKeys = array_keys($camelCaps);
    foreach ($listKeys as $listKey) {
      $temp[$this->uncamelize($listKey)] = $camelCaps[$listKey];
    }
    return $temp;
  }


}
