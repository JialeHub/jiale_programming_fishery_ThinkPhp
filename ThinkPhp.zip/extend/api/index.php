<?php


namespace api;

use \api\Request\index as Request;

/**
 * 第三方API
 * @package api
 */
class index
{
    /**
     * @param $ip
     * @return mixed
     */
    public function getIPInfo($ip = '')
    {
        $data = [];
        if (is_string($ip) && preg_match("/\A192.168.((([0-9]?[0-9])|(1[0-9]{2})|(2[0-4][0-9])|(25[0-5]))\.)(([0-9]?[0-9])|(1[0-9]{2})|(2[0-4][0-9])|(25[0-5]))\Z/", explode(",", $ip)[0])) {
            // 192.168.*.*
            $data = [
                "ip" => $ip,
                "pro" => "",
                "proCode" => "999999",
                "city" => "",
                "cityCode" => "0",
                "region" => "",
                "regionCode" => "0",
                "addr" => " 局域网",
                "regionNames" => "",
                "err" => "noprovince"
            ];
        } elseif ($ip === '127.0.0.1') {
            $data = [
                "ip" => $ip,
                "pro" => "",
                "proCode" => "999999",
                "city" => "",
                "cityCode" => "0",
                "region" => "",
                "regionCode" => "0",
                "addr" => " 本机地址",
                "regionNames" => "",
                "err" => "noprovince"
            ];
        } elseif ($ip === '0.0.0.0') {
            $data = [
                "ip" => $ip,
                "pro" => "",
                "proCode" => "999999",
                "city" => "",
                "cityCode" => "0",
                "region" => "",
                "regionCode" => "0",
                "addr" => " IANA保留地址",
                "regionNames" => "",
                "err" => "noprovince"
            ];
        } elseif (is_string($ip) && preg_match("/\A((([0-9]?[0-9])|(1[0-9]{2})|(2[0-4][0-9])|(25[0-5]))\.){3}(([0-9]?[0-9])|(1[0-9]{2})|(2[0-4][0-9])|(25[0-5]))\Z/", explode(",", $ip)[0])) {
            $ip = explode(",", $ip)[0]; //只识别第一个
            $request = new Request();
            $data['ip'] = $ip;
            $url = 'http://whois.pconline.com.cn/ipJson.jsp?ip=' . $data['ip'] . '&' . 'json=true';
            $headers = array(
                "content-type: application/x-www-form-urlencoded; charset=UTF-8",
                'CLIENT-IP:' . $ip,
                'X-FORWARDED-FOR:' . $ip,
            );
            $res = $request->httpRequest($url, 'get', $data, $headers);
            $data = json_decode($res);
        } else {
            $data = null;
        }
        return $data;
    }
}
