<?php


namespace fileInfo;


use utils\index as utils;

class index
{
    public $filename = null;
    public $imgInfo = null;

    /**
     * index constructor.
     * @param $filename
     */
    public function __construct($filename = null)
    {
        $this->filename = $filename;
        $this->imgInfo = $this->getImgInfo();
    }

    /**
     * 读取图片信息
     * @param null $filename
     * @return array|null
     */
    public function getImgInfo($filename = null){
        try {
            $data = exif_read_data($filename?$filename:$this->filename);
            $utils = new utils();
            if (key_exists('GPSLongitude',$data))$data['GPSLongitudeD']=$utils->Dms2D($data['GPSLongitude']);//经度
            if (key_exists('GPSLatitude',$data))$data['GPSLatitudeD']=$utils->Dms2D($data['GPSLatitude']);//纬度
            return $data;
        }catch (\Exception $e) {  //如书写为（Exception $e）将无效
            return null;
        }
    }

    public function getAll(){
        $data = [];
        if ($this->imgInfo) $data['imgInfo'] = $this->imgInfo;
        return $data;
    }


}
